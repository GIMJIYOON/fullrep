package kr.ac.doyayang.www.test1;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

      WebView webview = (WebView) findViewById(R.id.webview);
      webview.setWebViewClient(new WebViewClient());
      WebSettings websetting = webview.getSettings();
      websetting.setJavaScriptEnabled(true);
      websetting.setBuiltInZoomControls(true);
      webview.loadUrl("http://52.79.128.82:3000/#");
    }
}
